export const environment = {
  urlBase: 'http://localhost:8080/api/v1',
  urlAuth: '/auth',
  urlUser: '/user',
  socketUrl: 'http://localhost:8080',
};
