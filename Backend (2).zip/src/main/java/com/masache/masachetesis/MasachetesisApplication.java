package com.masache.masachetesis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MasachetesisApplication {
    public static void main(String[] args) {
        SpringApplication.run(MasachetesisApplication.class, args);
    }
}










































